# Taufeeq Mohammad – Portfolio

A static portfolio website. There is no build step and no dependencies. The only external request is Google Fonts (Inter and Instrument Serif).

```
index.html   page structure
styles.css   all styling
app.js       all behaviour (routing, animation, music, splash video)
assets/      videos, music, images and fonts (22 files, about 5.7 MB)
```

## Run it locally
Serve the folder (the video and audio need a server, not a double-click):

```bash
python3 -m http.server 8000   # then open http://localhost:8000
```

## Put it live with GitHub Pages
**No terminal needed:**
1. Create a new public repository on GitHub.
2. Click **Add file > Upload files**, drag in `index.html`, `styles.css`, `app.js`, `README.md` and the whole `assets` folder, then **Commit changes**.
3. Open **Settings > Pages**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then **Save**.
4. After about a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.

**With the terminal:**
```bash
git init && git add . && git commit -m "Add portfolio"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Name the repository `<your-username>.github.io` to get the shorter address `https://<your-username>.github.io/`.

## Things to edit (in `app.js`, near the top)
- `LINKS` – Résumé, Behance and LinkedIn URLs. The résumé link is empty for now.
- `MAIL` – contact email.
- `RAW` – project titles, descriptions and outcomes.
- `Q` – feedback quotes.

Pages use hash routing (`#/work`, `#/case/prism`), so no server settings are needed.
